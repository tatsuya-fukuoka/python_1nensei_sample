print(1+1)

print(100-1)

print("Hello")

print("答えは", 10+20)

print('私は"おはよう"といった。')
