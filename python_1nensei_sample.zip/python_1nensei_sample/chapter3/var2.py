h = 1.71
w = 64
bmi = w / (h * h)
print(bmi)