w = "こんにちは。" + "私はパイソンです。"
print(w[0])
print(w[6:12])
print(w[-3:])