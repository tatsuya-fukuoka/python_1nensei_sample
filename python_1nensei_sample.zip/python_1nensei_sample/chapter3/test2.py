a = "100"
b = "こんにちは"
print(a.isdigit())
print(b.isdigit())
