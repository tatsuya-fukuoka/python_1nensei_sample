from tax import *

print(postTaxPrice(100),"円")
print(postTaxPrice(128),"円")
print(postTaxPrice(980),"円")
