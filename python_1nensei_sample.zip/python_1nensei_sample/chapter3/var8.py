a = "100"
print(int(a)+23)
