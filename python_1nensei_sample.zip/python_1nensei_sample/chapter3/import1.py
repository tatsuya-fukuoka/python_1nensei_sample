import tax

print(tax.postTaxPrice(100),"円")
print(tax.postTaxPrice(128),"円")
print(tax.postTaxPrice(980),"円")
