score = 60
if score >= 80:
    print("やったね！")
    print("次もこの調子だ")
else:
    print("残念でした")