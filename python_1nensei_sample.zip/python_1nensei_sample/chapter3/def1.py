def sayhello():
    print("こんにちは")

sayhello()
sayhello()
sayhello()
