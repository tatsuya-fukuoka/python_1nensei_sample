a = 10
print(a)